# marker_msgs
ROS message to discribe detected marker and the sensor. The https://github.com/tuw-robotics/marker_rviz_plugin can be used for visualization. 
