^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package marker_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.5 (2016-09-30)
------------------
* new msgs
* Removed MarkerCandidate messages. Use Fiducial.msg and FiducialDetection.msg instead.
* Changed MarkerCandidate* to Fiducial*
* Fiducial msg added
* Fiducial msg added
* gitignore added
* Merge branch 'master' into devel
* header to msg/MarkerCandidate.msg added
* merge
* Added MarkerCandidate/Array messages.
* marker_msg type added
* Contributors: Markus Bader, Markus Bader @ munin, doctorseus

0.0.4 (2016-08-18)
------------------
* build system cleanup
* Contributors: Markus Bader

0.0.3 (2016-08-17)
------------------
* detection type added
* Contributors: Markus Bader

0.0.2 (2016-07-20)
------------------
* Added support of multiple ids with confidence
* msgs added
* Initial commit
* Contributors: Markus Bader, Markus Macsek
